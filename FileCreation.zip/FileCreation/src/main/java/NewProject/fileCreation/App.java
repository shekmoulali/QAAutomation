package NewProject.fileCreation;

import java.io.IOException;

public class App 
{
    public static void main( String[] args ) throws IOException
    {
    	OutputStream str=new OutputStream();
    	str.logAppender("Finance"+"\r\n"+"Finance");
    	int lineCount=str.countlines();
    	System.out.println("Number of Lines present : "+lineCount);
    	if (lineCount<600 || lineCount>700) {
			System.out.println("Error: As per Expectation the number of lines should be minimum 600 and Maximum 700");
			
		}
    str.numberOfCharinEachLine();
//        System.out.println( "Hello World!" );
    }
}
