package NewProject.fileCreation;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

import org.apache.commons.lang3.RandomStringUtils;

public class OutputStream {
	public static File file;
	public static int length; 
	FileWriter fw=null;
	BufferedWriter bfw=null;
	PrintWriter pw=null;
	
	public OutputStream() throws IOException{
	String userDir = System.getProperty("user.dir");
	System.out.println(userDir);
	file =new File(userDir+"\\"+"src"+"\\"+"TestFileFinance.txt");
	createLogDirectory(false);
	}
	public void createfile() throws IOException {
	
    FileOutputStream fout=new FileOutputStream(file);
    BufferedOutputStream bous=new BufferedOutputStream(fout);
	System.out.println("File is created");
	}
	
	public void logAppender(String message) throws IOException {
		
		
		try {
			boolean directoryExists=false;
			createLogDirectory(directoryExists);
			fw=new FileWriter(file,true);
			bfw=new BufferedWriter(fw);
			pw=new PrintWriter(bfw);
			int lengthappender = 0;
			for (int i = 0; i < 13000; i++) {
				
			message=generateRandowmWords(1, 15);
			length=length+message.length();
			System.out.println("Word length "+ length);
			if (length>120) {
				pw.print("\n");
				length=0;
			}
			
			pw.print(message);
		
			Reader in = new InputStreamReader(new FileInputStream(file), "UTF-16");
			System.out.println(in);
			pw.flush();
			directoryExists=true;
			System.out.println(message);
			}
			int randomline=insertKeyAtRandomPosition(1, countlines());
			System.out.println("Random line is "+randomline);
			int noOfCharsinRandomLine=getnoOfcharsinLine(randomline);
			System.out.println("Number of Chars in Random Line :"+noOfCharsinRandomLine);
			
			if (noOfCharsinRandomLine>120) {
				noOfCharsinRandomLine=noOfCharsinRandomLine-7;	
			}
					
			RandomAccessFile raf = new RandomAccessFile(file, "rw");
			raf.seek(noOfCharsinRandomLine);
			raf.write(" Finance ".getBytes());
			 randomline=insertKeyAtRandomPosition(1, countlines());
			System.out.println("Random line is "+randomline);
			 noOfCharsinRandomLine=getnoOfcharsinLine(randomline);
			System.out.println("Number of Chars in Random Line :"+noOfCharsinRandomLine);
			if (noOfCharsinRandomLine>120) {
				noOfCharsinRandomLine=noOfCharsinRandomLine-7;	
			}			
			raf.seek(noOfCharsinRandomLine);
			raf.write(" finance ".getBytes());
			
			pw.print("\n");
			pw.print("<EOF>");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {
			pw.close();
			bfw.close();
			fw.close();
			}
		
		
	}
	
	public void appendValue(int noOfCharsinRandomLine,String text) throws IOException {

		RandomAccessFile raf = new RandomAccessFile(file, "rw");
		raf.seek(noOfCharsinRandomLine);
		raf.write(text.getBytes());
	}
	
	public void createLogDirectory(boolean directoryExists) throws IOException {
		
		if (!directoryExists) {
			file.createNewFile();
		}
	}
	
	public static String generateRandowmWords(int minLength, int maxLength ) {
	String randomstr = null;
			randomstr= RandomStringUtils.randomAlphabetic(minLength, maxLength);
          randomstr=randomstr+" ";
		return randomstr;
        
	}
	
	
	public int insertKeyAtRandomPosition(int min,int max) {
		
		int b = (int)(Math.random()*(max-min+1)+min);
		return b;  
	}
	
    public int countlines() throws IOException {
    	
    	BufferedReader reader = new BufferedReader(new FileReader(file));
    	int lines = 0;
    	while (reader.readLine() != null) {
    	lines++;
    	System.out.println("The Number of lines is "+lines);
    	}
    	return lines;
    	
    }
    
    public void numberOfCharinEachLine() throws IOException {
 
        Scanner sc = new Scanner(file);
		while (sc.hasNextLine()) {
          String str1=sc.nextLine();
          
          System.out.println("Line Text - "+str1);
          char[] ch=str1.toCharArray();
          int n=ch.length;
         System.out.println(ch.length);	
        	  if (n<60 || n>120) {
        		  
        		  if (n>120) {
        			  pw.print("\n");
        			  
				}
				System.out.println("Error: As per Expectation in each line, minimum number of Characters allowed is 60 and Maximum is 120");
			}
			
		}
		}
    
    public int getnoOfcharsinLine(int lineNum) throws FileNotFoundException {
    	Scanner input = new Scanner(new FileReader(file));
    	int lines = 0;
    	int characters = 0;
    	int maxCharacters = 0;
        int lineNo = 1;
    	int charsInSecondLine = 0;
    	String longestLine = "";

    	while (input.hasNextLine()) {
    	    String line = input.nextLine();
    	    lines++;
    	    characters += line.length();

    	    if (maxCharacters < line.length()) {
    	        maxCharacters = line.length();
    	        longestLine = line;
    	    }

    	    if(lineNo==lineNum){
    	        charsInSecondLine=line.length();
    	        
    	    }
    	    lineNo++;
    	}
    	return charsInSecondLine;
    }
   
          
}
      
